# Fitness-Tracker-Dashboard
A responsive webpage dashboard used to track a user's fitness and overall health
